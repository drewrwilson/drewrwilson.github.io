Original image (flag_tag.png) (c) 2012 Code For America Labs Inc.

Available from:
http://codeforamerica.org/wp-content/uploads/2013/03/flag_tag.png

All other files created by Paul Kastner and Drew Wilson, 2014.

All files (including flag_tag.png) Licensed under Creative Commons Attribution-ShareAlike 3.0

http://creativecommons.org/licenses/by-sa/3.0/


You are free to:

Share — copy and redistribute the material in any medium or format

Adapt — remix, transform, and build upon the material
for any purpose, even commercially.

The licensor cannot revoke these freedoms as long as you follow the license terms.


For any questions regarding the included files or for help using them to make a physical object, contact pk@paulkastner.com